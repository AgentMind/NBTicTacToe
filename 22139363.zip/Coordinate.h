#ifndef Coordinate_Assignment
#define Coordinate_Assignment


struct Coordinate {
    int x;
    int y;
};










#endif